/*
 * John Goettsche
 * CS445
 *
 * contains the definitions for error handler
 */

#define UNREC_TOKEN 1
#define COM_CLOSE 2
#define STRING_CLOSE 3
#define MALF_CHAR 4
#define MALLOC_E 10